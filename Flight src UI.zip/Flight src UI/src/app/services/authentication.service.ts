import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoginDto } from 'src/app/dtos/login-dto';
import { User } from 'src/app/dtos/user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private httpClient:HttpClient) { }

  //Retrieves user token and checks authentication
  authenticate(loginDto:LoginDto) {

    return this.httpClient.post('http://localhost:8070/login',
    loginDto,{
      headers : {
        "content-type" : "application/json"
      }
    });
  }



  // Removes user session(logout)
  logOut() {
    sessionStorage.removeItem('username');
  }

  // Adds a new User
  signUp(user: User) {
    return this.httpClient.post('http://localhost:8070/api/v1.0/flight/airline/register', user);
  }
}
