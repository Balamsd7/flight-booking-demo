import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { LoginDto } from 'src/app/dtos/login-dto';
import { ResponseDataDto } from 'src/app/dtos/response-data-dto';
import swal from 'sweetalert2'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username = '';
  password = '';
  data: ResponseDataDto={
    message: '',
    result: null
  };
  loginDto: LoginDto={
    userName: '',
    roleId: 0,
    password: '',
    token: ''
  };
  invalidLogin = false;

  constructor(private router:Router, private loginService:AuthenticationService) { }

  ngOnInit(): void {
  }

    // Check user for authenticatoin
    checkLogin() {
      const loginObs = this.loginService.authenticate(this.loginDto);

        loginObs.subscribe((response:any) =>{
          
          this.data = response;          
          sessionStorage.setItem('username', this.loginDto.userName);
          let tokenStr = 'Bearer ' +this.data.result.token;
          sessionStorage.setItem('token', tokenStr);
          swal.fire('Success!', 'Logged in successfully!', 'success');
          console.log("Login Success");
          this.redirect();
        },(error:any) =>{
        console.log("Invalid Login Credentials..");
        this.invalidLogin = true;
        }
      );
    }
  
    // Redirect based on the user role
    redirect() {
      if(this.data.result.roleId === 2) {
        sessionStorage.setItem('role', 'user');
        sessionStorage.setItem('userName', String(this.loginDto.userName));
        this.invalidLogin = false;
        this.router.navigate(["/userpanel"]).then(()=> {
          window.location.reload();
        });
      }
      else if(this.data.result.roleId === 1) {
        sessionStorage.setItem('role', 'admin');
        sessionStorage.setItem('userName', String(this.loginDto.userName));
        this.invalidLogin = false;
        this.router.navigate(["adminpanel"]).then(()=> {
          window.location.reload();
        });
      }
    }
    navigateToSignUp(){
      this.router.navigate(["register"]);
    }

}
