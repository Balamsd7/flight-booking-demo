export class ResponseDataDto {
    message: string;
    result: any;
    constructor(){
        this.message = '';
        this.result = null;
    }
}
