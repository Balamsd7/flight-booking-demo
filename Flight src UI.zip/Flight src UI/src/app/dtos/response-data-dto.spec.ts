import { ResponseDataDto } from './response-data-dto';

describe('ResponseDataDto', () => {
  it('should create an instance', () => {
    expect(new ResponseDataDto()).toBeTruthy();
  });
});
