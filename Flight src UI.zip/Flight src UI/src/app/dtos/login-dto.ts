export class LoginDto {
    userName: string;
    roleId: number;
    password: string;
    token: string;
    constructor(){
        this.userName = '';
        this.roleId = 0;
        this.password = '';
        this.token = '';
    }

}
