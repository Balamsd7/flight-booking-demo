export class User {
    userName!: string
    password!: string
    emailId!: string
    mobileNumber!: number
}
