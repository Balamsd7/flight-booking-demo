package com.balamsd7.flightbooking.dto;

import lombok.Data;

@Data
public class ResponseDataDto {
    private String message;
    private Object result;
}
