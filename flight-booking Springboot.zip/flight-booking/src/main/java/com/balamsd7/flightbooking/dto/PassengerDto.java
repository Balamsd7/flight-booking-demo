package com.balamsd7.flightbooking.dto;

import lombok.Data;

@Data
public class PassengerDto {
    private String name;
    private String gender;
    private int age;
}
